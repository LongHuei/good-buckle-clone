<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Language" content="zh-cn" />
<title>404</title>
</head>
<body>
<div align=center style="margin-top: 100px;">
<iframe src="https://security.focuschina.com/go.html" frameborder="0"  scrolling=no allowtransparency=yes  style="width: 960px;height: 300px;VISIBILITY: inherit; ">
</div>
</body>
</html>

